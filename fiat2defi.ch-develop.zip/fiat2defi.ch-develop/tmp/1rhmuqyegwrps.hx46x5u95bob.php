<section class="funktion" id="funktion">
	<div class="container">
		<div class="section-title" data-aos="fade-up">
			<h2>
				Our Vision</h2>
		</div>
		<div class="row content">
			<div class="col-lg-6" data-aos="fade-up" data-aos-delay="150">
				<p style="text-align:justify">
					An app with which all shares, crytocurrencies and other assets that can be traded on Defichain can be traded around the clock, resistant to censorship, and where the user always has full control over his investments. No one can expropriate you.</p>
			</div>
			<div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-up" data-aos-delay="300">
				<p style="text-align:justify">
					<img alt="" src="/assets/img/mobile-app%402x.png" style="width: 404px; height: 192px;" /></p>
			</div>
		</div>
	</div>
</section>
<br />
