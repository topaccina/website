<?php echo $this->render('legal/sections/legal.htm',NULL,get_defined_vars(),0); ?>
