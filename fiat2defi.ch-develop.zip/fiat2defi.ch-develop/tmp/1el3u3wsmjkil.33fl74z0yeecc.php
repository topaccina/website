<?php echo $this->render('home/sections/startpage.htm',NULL,get_defined_vars(),0); ?>
<?php echo $this->render('home/sections/partners.htm',NULL,get_defined_vars(),0); ?>
<?php echo $this->render('home/sections/about.htm',NULL,get_defined_vars(),0); ?>