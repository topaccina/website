<section class="roadmap" id="roadmap">
	<div class="container">
		<div class="section-title" data-aos="fade-up">
			<h2>
				<span style="text-align: justify;">Roadmap</span></h2>
		</div>
		<div class="row content">
			<div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-up" data-aos-delay="300">
				<div>
					Stage 1: Buying DeFi assets is possible without KYC up to 900 EUR per day. The referral link system is already fully functional.</div>
				<div>
					&nbsp;</div>
				<div>
					Stage 2: Purchase of DeFi assets is possible with optional KYC at an unrestricted level.</div>
				<div>
					&nbsp;</div>
				<div>
					Level 3: It is also possible to sell DeFi Assets.</div>
				<p style="text-align:justify">
					<br />
					When will we be done with it?
Decentral Finance Exchange is an open source community project. Its success depends on each individual. Join our team to contribute and accelerate the development.&nbsp;</p>
			</div>
		</div>
	</div>
</section>
<br />
