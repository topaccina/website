<?php echo $this->render('about/sections/about.htm',NULL,get_defined_vars(),0); ?>
