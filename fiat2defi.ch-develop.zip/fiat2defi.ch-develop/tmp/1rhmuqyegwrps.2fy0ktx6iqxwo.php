<section class="about" id="about">
	<div class="container">
		<div class="section-title" data-aos="fade-up">
			<h2>
				&Uuml;ber Decentral Finance Exchange</h2>
		</div>
		<div class="row content">
			<div class="col-lg-6" data-aos="fade-up" data-aos-delay="150">
				<p style="text-align:justify">
					DeFiChain Exchange ist ein Community Projekt welches das Ziel hat unkompliziert und einfach DeFi Assets gegen EUR, CHF und USD zu verkaufen. Nach eingang des Geldes wird das gekaufte Asset mittels Blockchain Transaktion auf die Kunden Adresse transferiert.&nbsp;Kunden kontrollieren ihre Assets nach dem Kauf selber &uuml;ber den Privatkey.</p>
				<ul>
					<li><i class="ri-check-double-line"></i>bearbeitung innerhalb von einem Arbeitstag</li>
					 <li><i class="ri-check-double-line"></i>einfach zu verwenden</li>
					 <li><i class="ri-check-double-line"></i>KYC frei bis 1&#39;000 CHF oder 900 EUR pro Tag</li>
				</ul>
			</div>
			<div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-up" data-aos-delay="300">
				<p style="text-align:justify">
					&nbsp; &nbsp;<br />
					<a style="width: 300px; height: 300px;" /></a></p>
				<br />
				<br />
				<span style="text-align: justify;">&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><a </a></div>
		</div>
	</div>
</section>
<br />
