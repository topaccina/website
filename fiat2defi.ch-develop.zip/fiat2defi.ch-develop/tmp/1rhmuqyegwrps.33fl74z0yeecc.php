<?php echo $this->render('home/sections/startpage.htm',NULL,get_defined_vars(),0); ?>
<?php echo $this->render('home/sections/about.htm',NULL,get_defined_vars(),0); ?>
<?php echo $this->render('home/sections/vision.htm',NULL,get_defined_vars(),0); ?>
<?php echo $this->render('home/sections/funktion.htm',NULL,get_defined_vars(),0); ?>
<?php echo $this->render('home/sections/roadmap.htm',NULL,get_defined_vars(),0); ?>