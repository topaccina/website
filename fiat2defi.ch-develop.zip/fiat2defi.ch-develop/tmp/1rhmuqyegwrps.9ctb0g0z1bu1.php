<header class="fixed-top d-flex align-items-center" id="header">
	<div class="container d-flex align-items-center">
		<div class="logo mr-auto">
			<h1 style="display:none;">
				DeFiChain Exchange</h1>
			<a href="/"><img alt="DeFiChain Promo - Logo" class="img-fluid" src="/assets/img/defipromo_logos/logo_defichange-2.png" /></a></div>
		<nav class="nav-menu d-none d-lg-block">
			<ul>
				<li class="active">
					<a href="/">Home</a></li>
				<li class="drop-down">
					<a href="">Social Media Posts</a>
					<ul>
						<li>
							<a href="/twitter">Twitter</a></li>
						<li>
							<a href="/reddit">Reddit</a></li>
						<li>
							<a href="/youtube">Youtube</a></li>
						<li class="get-started">
							<a href="/submitpost">Submit Post</a></li>
					</ul>
				</li>
			</ul>
		</nav>
		<!-- .nav-menu --></div>
</header>
<br />
