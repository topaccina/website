  <section id="partners" class="partners">
    <div class="container">

      <div class="row">

        <div class="col-lg-2 col-md-4 col-6">
			<a href=https://defichain.com target="blank"><img src="/assets/img/partners/partner1.png" class="img-fluid" alt="" data-aos="zoom-in"></a>
        </div>

        <div class="col-lg-2 col-md-4 col-6">
			<a href=https://www.cakedefi.com/ target="blank"><img src="/assets/img/partners/partner2.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="100"></a>
		</div>

        <div class="col-lg-2 col-md-4 col-6">
			<a href=https://defichain-explained.com/ target="blank"><img src="/assets/img/partners/partner3.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="200"></a>
        </div>

        <div class="col-lg-2 col-md-4 col-6">
			<a href=https://www.defichain-analytics.com/ target="blank"><img src="/assets/img/partners/partner4.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="300"></a>
        </div>

        <div class="col-lg-2 col-md-4 col-6">
			<a href=https://defichain-wiki.com/wiki/Main_Page target="blank"><img src="/assets/img/partners/partner5.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="400"></a>
        </div>

        <div class="col-lg-2 col-md-4 col-6">
			<a href=https://www.defichain-income.com/ target="blank"><img src="/assets/img/partners/partner6.png" class="img-fluid" alt="" data-aos="zoom-in" data-aos-delay="500"></a>
        </div>

      </div>

    </div>
  </section>
  
  
