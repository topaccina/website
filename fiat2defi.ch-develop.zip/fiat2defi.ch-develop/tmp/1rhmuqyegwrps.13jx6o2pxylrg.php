<?php echo $this->render('en/sections/startpage.htm',NULL,get_defined_vars(),0); ?>
<?php echo $this->render('en/sections/about.htm',NULL,get_defined_vars(),0); ?>
<?php echo $this->render('en/sections/vision.htm',NULL,get_defined_vars(),0); ?>
<?php echo $this->render('en/sections/funktion.htm',NULL,get_defined_vars(),0); ?>
<?php echo $this->render('en/sections/roadmap.htm',NULL,get_defined_vars(),0); ?>
