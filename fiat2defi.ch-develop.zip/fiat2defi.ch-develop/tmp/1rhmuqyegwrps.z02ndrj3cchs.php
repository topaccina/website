<section class="roadmap" id="roadmap">
	<div class="container">
		<div class="section-title" data-aos="fade-up">
			<h2>
				<span style="text-align: justify;">Legal Notice</span></h2>
		</div>
		<div class="row content">
			<div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-up" data-aos-delay="300">
				<div>
					Legal 1</div>
				<div>
					&nbsp;</div>
				<div>
					Legal 2</div>
				<div>
					&nbsp;</div>
				<div>
					Legal 3</div>
				<p style="text-align:justify">
				</p>
			</div>
		</div>
	</div>
</section>
<br />
