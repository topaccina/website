<section class="funktion" id="funktion">
	<div class="container">
		<div class="section-title" data-aos="fade-up">
			<h2>
				Unsere Vision</h2>
		</div>
		<div class="row content">
			<div class="col-lg-6" data-aos="fade-up" data-aos-delay="150">
				<p style="text-align:justify">
					Eine App mit der alle auf der alle auf der Defichain handelbaren Aktien, Krytow&auml;hrungen und sonstigen Assets rund um die Uhr, zensurresistent gehandelt werden k&ouml;nnen, und bei der der Nutzer immer die volle Kontrolle &uuml;ber seine Anlagen hat. Niemand kann Sie enteignen.</p>
			</div>
			<div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-up" data-aos-delay="300">
				<p style="text-align:justify">
					<img alt="" src="/assets/img/mobile-app%402x.png" style="width: 404px; height: 192px;" /></p>
			</div>
		</div>
	</div>
</section>
<br />
