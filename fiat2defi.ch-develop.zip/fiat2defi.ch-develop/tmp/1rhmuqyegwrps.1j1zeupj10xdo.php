<section class="roadmap" id="roadmap">
	<div class="container">
		<div class="section-title" data-aos="fade-up">
			<h2>
				<span style="text-align: justify;">Roadmap</span></h2>
		</div>
		<div class="row content">
			<div class="col-lg-6 pt-4 pt-lg-0" data-aos="fade-up" data-aos-delay="300">
				<div>
					Stufe 1: Kaufen von DeFi Assets ist ohne KYC bis 900 EUR am Tag m&ouml;glich. Das Referal Link System funktioniert schon voll.</div>
				<div>
					&nbsp;</div>
				<div>
					Stufe 2: Kaufen von DeFi Assets ist mittels optionalem KYC in uneingeschr&auml;nkter H&ouml;he m&ouml;glich.</div>
				<div>
					&nbsp;</div>
				<div>
					Stufe 3: Es ist auch m&ouml;glich DeFi Asssets zu verkaufen.&nbsp;</div>
				<p style="text-align:justify">
					<br />
					Wann sind wir damit fertig?&nbsp;<br />
					Decentral Finance Exchange ist ein Open Source Community Projekt. Der Erfolg h&auml;ngt von jedem einzelnen ab. Melde dich bei unserem Team um mitzuarbeiten und die Entwicklung zu beschleunigen.&nbsp;</p>
			</div>
		</div>
	</div>
</section>
<br />
